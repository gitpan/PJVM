package PJVM::Class::Attribute::Deprecated;

use strict;
use warnings;

use Object::Tiny qw(
);

sub new_from_io {
    my ($pkg, $io, $cp) = @_;
            
    my $self = $pkg->new(
    );
    
    return $self;
}

1;
__END__

=head1 NAME

PJVM::Class::Attribute::Deprecated -

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 INTERFACE
