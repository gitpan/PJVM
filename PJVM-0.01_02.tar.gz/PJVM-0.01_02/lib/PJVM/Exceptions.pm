package PJVM::Exceptions;

use strict;
use warnings;

1;
__END__

=head1 NAME

PJVM::Exceptions -

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 INTERFACE
