public class test2 {
	static {
		System.err.println("Loading");
	}
	
	static {
		System.err.println("Loaded");
	}
}