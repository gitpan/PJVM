public class test1 implements Cloneable {
	int		field1;
	Object	field2;
	
	public static void main(String[] args) {
		long l = 1000000000000L;
	}
	
	public int calc() {
		return 40 + 1;
	}
}